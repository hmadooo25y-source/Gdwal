import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import 'config.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  /// عند الضغط على إشعار مرتبط بأغنية نضع اسم الخانة هنا ليشغّلها التطبيق
  static final ValueNotifier<String?> tappedSlot = ValueNotifier<String?>(null);

  static AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  static Future<void> init() async {
    try {
      tzdata.initializeTimeZones();
      tz.setLocalLocation(tz.getLocation(kTimeZone));

      await _plugin.initialize(
        const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        ),
        onDidReceiveNotificationResponse: _onTap,
      );

      await _android?.createNotificationChannel(AndroidNotificationChannel(
        'daily_plan',
        'الخطة اليومية',
        description: 'تذكيرات الروتين والأقوال المأثورة',
        importance: Importance.max,
      ));

      await _android?.createNotificationChannel(AndroidNotificationChannel(
        'adhan_channel',
        'الأذان',
        description: 'تنبيه أوقات الصلاة',
        importance: Importance.max,
        playSound: true,
        sound: kHasBundledAdhan
            ? RawResourceAndroidNotificationSound('adhan')
            : null,
      ));
    } catch (_) {}
  }

  static void _onTap(NotificationResponse response) {
    final payload = response.payload;
    if (payload != null && payload.startsWith('slot:')) {
      tappedSlot.value = payload.substring(5);
    }
  }

  static NotificationDetails _details({required bool adhan}) {
    return NotificationDetails(
      android: AndroidNotificationDetails(
        adhan ? 'adhan_channel' : 'daily_plan',
        adhan ? 'الأذان' : 'الخطة اليومية',
        channelDescription: adhan ? 'تنبيه أوقات الصلاة' : 'تذكيرات الروتين',
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
      ),
    );
  }

  static Future<void> cancelAll() async {
    try {
      await _plugin.cancelAll();
    } catch (_) {}
  }

  /// إشعار فوري (للاختبار أو تنبيه المؤقت)
  static Future<void> showNow({required String title, required String body}) async {
    try {
      await _plugin.show(9000, title, body, _details(adhan: false));
    } catch (_) {}
  }

  /// جدولة إشعار في وقت محدد — يعمل والتطبيق مغلق
  static Future<void> schedule({
    required int id,
    required DateTime when,
    required String title,
    required String body,
    String? payload,
    bool adhan = false,
  }) async {
    if (when.isBefore(DateTime.now())) return;
    try {
      // إذا لم تُمنح صلاحية المنبهات الدقيقة نستخدم وضعاً تقريبياً بدل الفشل
      final exact = await _android?.canScheduleExactNotifications() ?? false;
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        tz.TZDateTime.from(when, tz.local),
        _details(adhan: adhan),
        androidScheduleMode: exact
            ? AndroidScheduleMode.exactAllowWhileIdle
            : AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: payload,
      );
    } catch (_) {}
  }
}
