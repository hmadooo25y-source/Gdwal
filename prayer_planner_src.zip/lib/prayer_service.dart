import 'dart:convert';

import 'package:http/http.dart' as http;

import 'config.dart';

class PrayerTimes {
  final Map<String, DateTime> times; // Fajr, Dhuhr, Asr, Maghrib, Isha
  const PrayerTimes(this.times);
}

class PrayerService {
  /// يجلب أوقات الصلاة ليوم معين من Aladhan API (مجاني ولا يحتاج مفتاح).
  static Future<PrayerTimes> fetch(DateTime date) async {
    final dd = date.day.toString().padLeft(2, '0');
    final mm = date.month.toString().padLeft(2, '0');
    final uri = Uri.parse(
      'https://api.aladhan.com/v1/timings/$dd-$mm-${date.year}'
      '?latitude=$kLatitude&longitude=$kLongitude&method=$kCalcMethod',
    );

    final res = await http.get(uri).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw Exception('Prayer API error ${res.statusCode}');
    }

    final timings = (jsonDecode(res.body)['data']['timings'] as Map)
        .cast<String, dynamic>();

    // القيم مثل "05:12 (IST)" — نأخذ الجزء الأول فقط
    DateTime parse(String raw) {
      final parts = raw.split(' ').first.split(':');
      return DateTime(
        date.year,
        date.month,
        date.day,
        int.parse(parts[0]),
        int.parse(parts[1]),
      );
    }

    return PrayerTimes({
      for (final k in ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'])
        k: parse(timings[k] as String),
    });
  }
}
