import 'dart:convert';

import 'package:http/http.dart' as http;

import 'config.dart';
import 'settings.dart';

class PrayerTimes {
  final Map<String, DateTime> times; // Fajr, Dhuhr, Asr, Maghrib, Isha
  const PrayerTimes(this.times);
}

class PrayerService {
  static String _key(DateTime date, Settings s) =>
      'prayer-${s.lat.toStringAsFixed(2)}-${s.lng.toStringAsFixed(2)}-'
      '${date.year}-${date.month}-${date.day}';

  static PrayerTimes? _readCache(String key, Settings s) {
    final raw = s.p.getString(key);
    if (raw == null) return null;
    final map = (jsonDecode(raw) as Map).cast<String, String>();
    return PrayerTimes({
      for (final e in map.entries) e.key: DateTime.parse(e.value),
    });
  }

  /// يجلب أوقات اليوم من الإنترنت ويحفظها محلياً.
  /// [preferCache] يعيد النسخة المحفوظة مباشرة إن وُجدت (للاستخدام المتكرر).
  static Future<PrayerTimes> getTimes(DateTime date, Settings s,
      {bool preferCache = false}) async {
    final key = _key(date, s);
    if (preferCache) {
      final cached = _readCache(key, s);
      if (cached != null) return cached;
    }
    try {
      final times = await _fetch(date, s);
      await s.p.setString(
        key,
        jsonEncode({
          for (final e in times.times.entries) e.key: e.value.toIso8601String(),
        }),
      );
      return times;
    } catch (_) {
      final cached = _readCache(key, s);
      if (cached == null) rethrow;
      return cached;
    }
  }

  static Future<PrayerTimes> _fetch(DateTime date, Settings s) async {
    final dd = date.day.toString().padLeft(2, '0');
    final mm = date.month.toString().padLeft(2, '0');
    final uri = Uri.parse(
      'https://api.aladhan.com/v1/timings/$dd-$mm-${date.year}'
      '?latitude=${s.lat}&longitude=${s.lng}&method=$kCalcMethod',
    );

    final res = await http.get(uri).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw Exception('Prayer API error ${res.statusCode}');
    }

    final timings = (jsonDecode(res.body)['data']['timings'] as Map)
        .cast<String, dynamic>();

    // القيم بصيغة "05:12 (IST)" — نأخذ الجزء الأول فقط
    DateTime parse(String raw) {
      final parts = raw.split(' ').first.split(':');
      return DateTime(
        date.year,
        date.month,
        date.day,
        int.parse(parts[0]),
        int.parse(parts[1]),
      );
    }

    return PrayerTimes({
      for (final k in ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'])
        k: parse(timings[k] as String),
    });
  }
}
