import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';

import 'theme.dart';

/// خلفية متدرجة حسب وقت اليوم مع نقوش هندسية خفيفة
class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: timeGradient(DateTime.now()),
        ),
      ),
      child: Stack(
        children: [
          const Positioned.fill(
            child: CustomPaint(painter: _IslamicPatternPainter()),
          ),
          child,
        ],
      ),
    );
  }
}

class _IslamicPatternPainter extends CustomPainter {
  const _IslamicPatternPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = AppColors.gold.withOpacity(0.12);

    final center = Offset(size.width * 0.9, size.height * 0.08);
    for (var i = 1; i <= 7; i++) {
      canvas.drawCircle(center, i * 42.0, line);
    }
    for (var i = 0; i < 8; i++) {
      final a = i * pi / 4;
      canvas.drawLine(center, center + Offset(cos(a), sin(a)) * 320, line);
    }

    final bottom = Offset(size.width * 0.05, size.height * 0.95);
    for (var i = 1; i <= 4; i++) {
      canvas.drawCircle(bottom, i * 60.0, line);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// بطاقة زجاجية شفافة مع ضبابية خفيفة
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? highlight;

  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.highlight,
  });

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(22);
    return ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Material(
          color: Colors.white.withOpacity(0.10),
          shape: RoundedRectangleBorder(borderRadius: radius),
          child: InkWell(
            onTap: onTap,
            borderRadius: radius,
            child: Container(
              width: double.infinity,
              padding: padding,
              decoration: BoxDecoration(
                borderRadius: radius,
                border: Border.all(
                  color: highlight ?? Colors.white.withOpacity(0.18),
                  width: highlight == null ? 1 : 2,
                ),
              ),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}

class PageHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  const PageHeader({super.key, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(subtitle,
              style: const TextStyle(color: Colors.white70, fontSize: 14)),
        ],
      ),
    );
  }
}
