import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// يُزاد عند تغيير ملخص أي يوم، فتعيد شاشة الإنجاز الرسم
final ValueNotifier<int> kSummaryVersion = ValueNotifier<int>(0);

String dayKeyOf(DateTime d) => '${d.year}-${d.month}-${d.day}';

class DaySummary {
  final int done;
  final int total;
  const DaySummary(this.done, this.total);
  double get ratio => total == 0 ? 0 : done / total;
}

Future<void> saveSummary(
    SharedPreferences p, DateTime day, int done, int total) async {
  await p.setString('sum-${dayKeyOf(day)}', '$done/$total');
  kSummaryVersion.value++;
}

DaySummary? readSummary(SharedPreferences p, DateTime day) {
  final raw = p.getString('sum-${dayKeyOf(day)}');
  if (raw == null) return null;
  final parts = raw.split('/');
  return DaySummary(int.parse(parts[0]), int.parse(parts[1]));
}

/// عدد الأيام المتتالية التي تجاوز فيها الإنجاز 50%.
/// إذا لم يكتمل اليوم الحالي بعد لا يُحسب ضده.
int streakOf(SharedPreferences p, DateTime today) {
  var streak = 0;
  var day = DateTime(today.year, today.month, today.day);
  for (var i = 0; i < 400; i++) {
    final s = readSummary(p, day);
    final ok = s != null && s.ratio >= 0.5;
    if (ok) {
      streak++;
    } else if (i > 0) {
      break;
    }
    day = day.subtract(const Duration(days: 1));
  }
  return streak;
}
