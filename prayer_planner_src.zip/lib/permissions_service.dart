import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

class PermSpec {
  final String title;
  final String why;
  final List<Permission> perms;
  const PermSpec(this.title, this.why, this.perms);
}

/// الترتيب مهم: 0 الإشعارات، 1 المنبهات الدقيقة، 2 الموقع، 3 الملفات، 4 البطارية
final List<PermSpec> kPermSpecs = [
  PermSpec('الإشعارات', 'لإرسال تنبيهات الصلاة والتحفيز',
      [Permission.notification]),
  PermSpec('المنبهات الدقيقة', 'لتصل الإشعارات في وقتها بالضبط',
      [Permission.scheduleExactAlarm]),
  PermSpec('الموقع', 'لحساب أوقات الصلاة حسب مكانك',
      [Permission.locationWhenInUse]),
  PermSpec('الملفات والصوت', 'لرفع ملفات الأذان والأغاني من هاتفك',
      [Permission.audio, Permission.storage]),
  PermSpec('تحسين البطارية', 'لمنع النظام من إيقاف الإشعارات في الخلفية',
      [Permission.ignoreBatteryOptimizations]),
];

Future<bool> isSpecGranted(PermSpec spec) async {
  for (final p in spec.perms) {
    if (await p.status.isGranted) return true;
  }
  return false;
}

Future<bool> requestSpec(PermSpec spec) async {
  for (final p in spec.perms) {
    final st = await p.request();
    if (st.isGranted) return true;
  }
  return false;
}

Future<Position?> currentPosition() async {
  try {
    if (!await Geolocator.isLocationServiceEnabled()) return null;
    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.medium,
    );
  } catch (_) {
    return null;
  }
}
