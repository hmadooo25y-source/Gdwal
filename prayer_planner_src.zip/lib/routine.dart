import 'package:flutter/material.dart';

import 'config.dart';
import 'prayer_service.dart';
import 'theme.dart';

class PlanItem {
  final String id;
  final String title;
  final String emoji;
  final DateTime time;
  final Color color;
  final Song? song;

  const PlanItem(this.id, this.title, this.emoji, this.time, this.color,
      {this.song});

  bool get isPrayer =>
      ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].contains(id);
}

String fmt(DateTime t) =>
    '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

DateTime _plus(DateTime t, int minutes) => t.add(Duration(minutes: minutes));

/// جدول يوم كامل بالترتيب الذي حددته:
/// الفجر ← فطور ← (جيم + شاور في أيام محددة) ← السوق ← الظهر ← مشروب
/// ← العصر ← دراسة/عمل ← المغرب ← المشي ← العشاء ← النوم
List<PlanItem> buildDay(DateTime day, PrayerTimes p) {
  final d = DateTime(day.year, day.month, day.day);
  DateTime at(int h, int m) => DateTime(d.year, d.month, d.day, h, m);

  final fajr = p.times['Fajr']!;
  final dhuhr = p.times['Dhuhr']!;
  final asr = p.times['Asr']!;
  final maghrib = p.times['Maghrib']!;
  final isha = p.times['Isha']!;

  final gymDay = kGymWeekdays.contains(d.weekday);

  final list = <PlanItem>[
    PlanItem('fajr', 'صلاة الفجر', '🕌', fajr, AppColors.gold),
    PlanItem('breakfast', 'فطور ومشروب صحي', '🍳', _plus(fajr, 60),
        AppColors.green),
  ];

  if (gymDay) {
    list.add(PlanItem('gym', 'رياضة في الجيم', '🏋️',
        at(kGymHour, kGymMinute), AppColors.rose,
        song: kSongs['gym']));
    list.add(PlanItem('shower', 'أخذ شاور', '🚿', at(9, 0), AppColors.sky));
  }

  list.addAll([
    PlanItem('market', 'الذهاب إلى السوق', '🛒', at(9, 30), AppColors.amber),
    PlanItem('dhuhr', 'صلاة الظهر', '🕌', dhuhr, AppColors.gold),
    PlanItem('drink', 'مشروب صحي', '🥤', _plus(dhuhr, 15), AppColors.green),
    PlanItem('asr', 'صلاة العصر', '🕌', asr, AppColors.gold),
    PlanItem('study', 'دراسة أو عمل', '📚', _plus(asr, 15), AppColors.sky,
        song: kSongs['study']),
    PlanItem('maghrib', 'صلاة المغرب', '🕌', maghrib, AppColors.gold),
    PlanItem('walk', 'المشي', '🚶', _plus(maghrib, 15), AppColors.green,
        song: kSongs['walk']),
    PlanItem('isha', 'صلاة العشاء', '🕌', isha, AppColors.gold),
    PlanItem('sleep', 'النوم', '😴', _plus(isha, 30), AppColors.indigo),
  ]);

  list.sort((a, b) => a.time.compareTo(b.time));
  return list;
}
