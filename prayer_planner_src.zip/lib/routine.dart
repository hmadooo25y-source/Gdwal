import 'config.dart';
import 'prayer_service.dart';

class PlanItem {
  final String id;
  final String title;
  final String emoji;
  final DateTime time;
  final Song? song;

  PlanItem(this.id, this.title, this.emoji, this.time, {this.song});

  bool get isPrayer =>
      ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].contains(id);
}

DateTime _plus(DateTime t, int minutes) =>
    t.add(Duration(minutes: minutes));

/// يبني جدول يوم كامل بالترتيب الذي حددته:
/// الفجر ← فطور ← (جيم + شاور في أيام محددة) ← السوق ← الظهر ← مشروب
/// ← العصر ← دراسة/عمل ← المغرب ← المشي ← العشاء ← النوم
List<PlanItem> buildDay(DateTime day, PrayerTimes p) {
  final d = DateTime(day.year, day.month, day.day);
  DateTime at(int h, int m) => DateTime(d.year, d.month, d.day, h, m);

  final fajr = p.times['Fajr']!;
  final dhuhr = p.times['Dhuhr']!;
  final asr = p.times['Asr']!;
  final maghrib = p.times['Maghrib']!;
  final isha = p.times['Isha']!;

  final gymDay = kGymWeekdays.contains(d.weekday);

  final list = <PlanItem>[
    PlanItem('fajr', 'صلاة الفجر', '🕌', fajr),
    PlanItem('breakfast', 'فطور ومشروب صحي', '🍳', _plus(fajr, 60)),
  ];

  if (gymDay) {
    list.add(PlanItem(
      'gym',
      'رياضة في الجيم',
      '🏋️',
      at(kGymHour, kGymMinute),
      song: kSongs['gym'],
    ));
    list.add(PlanItem('shower', 'أخذ شاور', '🚿', at(9, 0)));
  }

  list.addAll([
    PlanItem('market', 'الذهاب إلى السوق', '🛒', at(9, 30)),
    PlanItem('dhuhr', 'صلاة الظهر', '🕌', dhuhr),
    PlanItem('drink', 'مشروب صحي', '🥤', _plus(dhuhr, 15)),
    PlanItem('asr', 'صلاة العصر', '🕌', asr),
    PlanItem('study', 'دراسة أو عمل', '📚', _plus(asr, 15),
        song: kSongs['study']),
    PlanItem('maghrib', 'صلاة المغرب', '🕌', maghrib),
    PlanItem('walk', 'المشي', '🚶', _plus(maghrib, 15),
        song: kSongs['walk']),
    PlanItem('isha', 'صلاة العشاء', '🕌', isha),
    PlanItem('sleep', 'النوم', '😴', _plus(isha, 30)),
  ]);

  list.sort((a, b) => a.time.compareTo(b.time));
  return list;
}
