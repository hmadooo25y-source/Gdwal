import 'package:flutter/material.dart';

import 'prayer_service.dart';
import 'settings.dart';
import 'theme.dart';

class PlanItem {
  final String id;
  final String title;
  final String emoji;
  final DateTime time;
  final Color color;
  final String? slot; // اسم الخانة الصوتية المرتبطة (gym / study / walk)

  const PlanItem({
    required this.id,
    required this.title,
    required this.emoji,
    required this.time,
    required this.color,
    this.slot,
  });

  bool get isPrayer =>
      const ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].contains(id);
}

String fmt(DateTime t) =>
    '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

DateTime _plus(DateTime t, int minutes) => t.add(Duration(minutes: minutes));

/// جدول يوم كامل حسب الإعدادات.
/// الترتيب الافتراضي: الفجر ← فطور ← (جيم + شاور) ← السوق ← الظهر ← مشروب
/// ← العصر ← دراسة ← المغرب ← المشي ← العشاء ← النوم، مع المهام الشخصية.
List<PlanItem> buildDay(DateTime day, PrayerTimes pt, Settings s) {
  final d = DateTime(day.year, day.month, day.day);
  DateTime at(TimeOfDay t) => DateTime(d.year, d.month, d.day, t.hour, t.minute);

  final fajr = pt.times['Fajr']!;
  final dhuhr = pt.times['Dhuhr']!;
  final asr = pt.times['Asr']!;
  final maghrib = pt.times['Maghrib']!;
  final isha = pt.times['Isha']!;
  final ram = s.ramadan;

  final list = <PlanItem>[];

  if (ram) {
    list.add(PlanItem(
      id: 'suhoor',
      title: 'السحور',
      emoji: '🥣',
      time: fajr.subtract(const Duration(minutes: 40)),
      color: AppColors.green,
    ));
  } else {
    list.add(PlanItem(
      id: 'breakfast',
      title: 'فطور ومشروب صحي',
      emoji: '🍳',
      time: _plus(fajr, 60),
      color: AppColors.green,
    ));
  }

  list.add(PlanItem(
      id: 'fajr', title: 'صلاة الفجر', emoji: '🕌', time: fajr, color: AppColors.gold));

  if (s.adhkar) {
    list.add(PlanItem(
      id: 'adhkar_m',
      title: 'أذكار الصباح',
      emoji: '📿',
      time: _plus(fajr, 30),
      color: AppColors.emerald,
    ));
  }

  if (s.gymDays.contains(d.weekday)) {
    list.add(PlanItem(
      id: 'gym',
      title: 'رياضة في الجيم',
      emoji: '🏋️',
      time: at(s.gymTime),
      color: AppColors.rose,
      slot: 'gym',
    ));
    list.add(PlanItem(
      id: 'shower',
      title: 'أخذ شاور',
      emoji: '🚿',
      time: at(s.showerTime),
      color: AppColors.sky,
    ));
  }

  list.add(PlanItem(
    id: 'market',
    title: 'الذهاب إلى السوق',
    emoji: '🛒',
    time: at(s.marketTime),
    color: AppColors.amber,
  ));

  list.add(PlanItem(
      id: 'dhuhr', title: 'صلاة الظهر', emoji: '🕌', time: dhuhr, color: AppColors.gold));

  if (!ram) {
    list.add(PlanItem(
      id: 'drink',
      title: 'مشروب صحي',
      emoji: '🥤',
      time: _plus(dhuhr, 15),
      color: AppColors.green,
    ));
  }

  list.add(PlanItem(
      id: 'asr', title: 'صلاة العصر', emoji: '🕌', time: asr, color: AppColors.gold));

  if (s.adhkar) {
    list.add(PlanItem(
      id: 'adhkar_e',
      title: 'أذكار المساء',
      emoji: '📿',
      time: _plus(asr, 20),
      color: AppColors.emerald,
    ));
  }

  list.add(PlanItem(
    id: 'study',
    title: 'دراسة أو عمل',
    emoji: '📚',
    time: _plus(asr, 45),
    color: AppColors.sky,
    slot: 'study',
  ));

  list.add(PlanItem(
      id: 'maghrib', title: 'صلاة المغرب', emoji: '🕌', time: maghrib, color: AppColors.gold));

  if (ram) {
    list.add(PlanItem(
        id: 'iftar', title: 'الإفطار', emoji: '🌙', time: maghrib, color: AppColors.amber));
  }

  list.add(PlanItem(
    id: 'walk',
    title: 'المشي',
    emoji: '🚶',
    time: _plus(maghrib, 20),
    color: AppColors.green,
    slot: 'walk',
  ));

  list.add(PlanItem(
      id: 'isha', title: 'صلاة العشاء', emoji: '🕌', time: isha, color: AppColors.gold));

  if (ram) {
    list.add(PlanItem(
      id: 'taraweeh',
      title: 'صلاة التراويح',
      emoji: '🌌',
      time: _plus(isha, 15),
      color: AppColors.indigo,
    ));
  }

  if (s.quranReminder) {
    list.add(PlanItem(
      id: 'quran',
      title: 'ورد القرآن',
      emoji: '📖',
      time: at(s.quranTime),
      color: AppColors.sky,
    ));
  }

  list.add(PlanItem(
    id: 'sleep',
    title: 'النوم',
    emoji: '😴',
    time: _plus(isha, 30),
    color: AppColors.indigo,
  ));

  for (final t in s.customTasks) {
    list.add(PlanItem(
      id: 'custom_${t.id}',
      title: t.title,
      emoji: t.emoji,
      time: at(TimeOfDay(hour: t.hour, minute: t.minute)),
      color: AppColors.rose,
    ));
  }

  list.sort((a, b) => a.time.compareTo(b.time));
  return list;
}
