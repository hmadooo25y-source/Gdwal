import 'package:shared_preferences/shared_preferences.dart';

import 'config.dart';
import 'content.dart';
import 'notification_service.dart';
import 'prayer_service.dart';
import 'routine.dart';

/// يجدول إشعارات الأيام السبعة القادمة.
/// يعمل في الخلفية ولا يؤثر على عرض الجدول إذا فشل.
Future<void> scheduleWeek(SharedPreferences prefs) async {
  await NotificationService.cancelAll();

  final base = DateTime.now();
  final start = DateTime(base.year, base.month, base.day);
  var counter = 0;

  for (var d = 0; d < 7; d++) {
    final day = start.add(Duration(days: d));
    try {
      final prayers = await PrayerService.getTimes(day, prefs);
      final list = buildDay(day, prayers);

      for (var i = 0; i < list.length; i++) {
        final it = list[i];
        final String body;
        if (it.isPrayer) {
          body = 'حيّ على الصلاة… حيّ على الفلاح';
        } else {
          // بالتناوب بين رسالة تحفيزية وقول مأثور عن الإمام علي (ع)
          body = counter.isEven
              ? kMotivation[counter % kMotivation.length]
              : kAliQuotes[counter % kAliQuotes.length].text;
        }
        counter++;

        await NotificationService.schedule(
          id: d * 100 + i,
          when: it.time,
          title: '${it.emoji} ${it.title}',
          body: body,
          url: it.song?.url,
        );
      }

      // إشعار "قول مأثور لهذا اليوم"
      await NotificationService.schedule(
        id: d * 100 + 90,
        when: DateTime(day.year, day.month, day.day, kDailyQuoteHour,
            kDailyQuoteMinute),
        title: '✨ قول مأثور لهذا اليوم',
        body: quoteOfDay(day).text,
      );
    } catch (_) {}
  }
}
