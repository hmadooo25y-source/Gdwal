import 'config.dart';
import 'content.dart';
import 'notification_service.dart';
import 'prayer_service.dart';
import 'routine.dart';
import 'settings.dart';

/// يجدول إشعارات الأيام السبعة القادمة، ويعمل بالخلفية دون التأثير على الشاشة.
Future<void> scheduleWeek(Settings s) async {
  await NotificationService.cancelAll();

  final now = DateTime.now();
  final start = DateTime(now.year, now.month, now.day);
  var counter = 0;

  for (var d = 0; d < 7; d++) {
    final day = start.add(Duration(days: d));
    try {
      final pt = await PrayerService.getTimes(day, s);
      final list = buildDay(day, pt, s);

      for (var i = 0; i < list.length; i++) {
        final it = list[i];

        final String body;
        if (it.isPrayer) {
          body = 'حيّ على الصلاة… حيّ على الفلاح';
        } else {
          // بالتناوب بين رسالة تحفيزية وقول مأثور عن الإمام علي (ع)
          body = counter.isEven
              ? kMotivation[counter % kMotivation.length]
              : kAliQuotes[counter % kAliQuotes.length].text;
        }
        counter++;

        await NotificationService.schedule(
          id: d * 200 + i,
          when: it.time,
          title: '${it.emoji} ${it.title}',
          body: body,
          payload: it.slot != null ? 'slot:${it.slot}' : null,
          adhan: it.isPrayer && s.adhan,
        );

        // تنبيه قبل الصلاة بعدد الدقائق المحدد
        if (it.isPrayer && s.preMinutes > 0) {
          await NotificationService.schedule(
            id: d * 200 + 100 + i,
            when: it.time.subtract(Duration(minutes: s.preMinutes)),
            title: '⏳ بعد ${s.preMinutes} دقيقة',
            body: '${it.title}… استعد للصلاة',
          );
        }
      }

      // قول مأثور لهذا اليوم
      await NotificationService.schedule(
        id: d * 200 + 190,
        when: DateTime(day.year, day.month, day.day, kDailyQuoteHour,
            kDailyQuoteMinute),
        title: '✨ قول مأثور لهذا اليوم',
        body: quoteOfDay(day).text,
      );
    } catch (_) {}
  }
}
