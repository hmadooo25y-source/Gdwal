import 'dart:async';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'audio_service.dart';
import 'content.dart';
import 'notification_service.dart';
import 'permissions_service.dart';
import 'prayer_service.dart';
import 'routine.dart';
import 'scheduler.dart';
import 'settings.dart';
import 'stats.dart';
import 'theme.dart';
import 'widgets.dart';

const Map<String, String> kFallbackQueries = {
  'gym': 'أغاني حماسية للرياضة والجيم',
  'study': 'موسيقى تركيز للدراسة',
  'walk': 'أناشيد حماسية للمشي',
};

/// يشغّل الملف المرفوع للخانة، وإن لم يُرفع ملف يفتح بحث يوتيوب
Future<void> playSlotOrOpen(Settings s, String slot) async {
  if (s.audioFor(slot) != null) {
    await AudioHub.playSlot(s, slot);
    return;
  }
  final q = kFallbackQueries[slot];
  if (q == null) return;
  await launchUrl(
    Uri.parse(
        'https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent(q)}'),
    mode: LaunchMode.externalApplication,
  );
}

class TodayPage extends StatefulWidget {
  const TodayPage({super.key});

  @override
  State<TodayPage> createState() => _TodayPageState();
}

class _TodayPageState extends State<TodayPage> {
  Settings? _s;
  bool _loading = true;
  String? _error;
  List<PlanItem> _items = [];
  Map<String, bool> _done = {};
  Timer? _ticker;

  @override
  void initState() {
    super.initState();
    kDataVersion.addListener(_reload);
    NotificationService.tappedSlot.addListener(_onSlotTap);
    _reload();
    _ticker = Timer.periodic(const Duration(minutes: 1), (_) {
      if (!mounted) return;
      setState(() {});
      final s = _s;
      if (s != null) AdhanWatcher.check(s);
    });
  }

  @override
  void dispose() {
    kDataVersion.removeListener(_reload);
    NotificationService.tappedSlot.removeListener(_onSlotTap);
    _ticker?.cancel();
    super.dispose();
  }

  void _onSlotTap() {
    final slot = NotificationService.tappedSlot.value;
    final s = _s;
    if (slot == null || s == null) return;
    NotificationService.tappedSlot.value = null;
    playSlotOrOpen(s, slot);
  }

  Future<void> _reload() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final s = await Settings.load();
      _s = s;
      final today = DateTime.now();
      final pt = await PrayerService.getTimes(today, s);
      final items = buildDay(today, pt, s);
      final key = dayKeyOf(today);
      final done = {
        for (final i in items) i.id: s.p.getBool('$key-${i.id}') ?? false,
      };
      if (!mounted) return;
      setState(() {
        _items = items;
        _done = done;
        _loading = false;
      });
      await _saveSummary();

      // طلب الصلاحيات الأساسية مرة واحدة عند أول تشغيل
      if (!s.p.containsKey('askedPerms')) {
        await s.p.setBool('askedPerms', true);
        await requestSpec(kPermSpecs[0]); // الإشعارات
        await requestSpec(kPermSpecs[1]); // المنبهات الدقيقة
      }

      scheduleWeek(s);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error =
            'تعذّر تحميل أوقات الصلاة.\nتأكد من اتصال الإنترنت ثم أعد المحاولة.';
      });
    }
  }

  Future<void> _toggle(PlanItem it, bool v) async {
    final s = _s;
    setState(() => _done[it.id] = v);
    if (s == null) return;
    await s.p.setBool('${dayKeyOf(DateTime.now())}-${it.id}', v);
    await _saveSummary();
  }

  Future<void> _saveSummary() async {
    final s = _s;
    if (s == null) return;
    final done = _done.values.where((e) => e).length;
    await saveSummary(s.p, DateTime.now(), done, _items.length);
  }

  PlanItem? _nextPrayer() {
    final now = DateTime.now();
    for (final it in _items) {
      if (it.isPrayer && it.time.isAfter(now)) return it;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return _errorView();

    final done = _done.values.where((v) => v).length;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      children: [
        _header(),
        _countdown(_nextPrayer()),
        const SizedBox(height: 12),
        _progress(done),
        const SizedBox(height: 12),
        _quote(),
        const SizedBox(height: 20),
        for (var i = 0; i < _items.length; i++)
          _tile(_items[i], i == _items.length - 1),
      ],
    );
  }

  Widget _errorView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_rounded, size: 56, color: AppColors.gold),
            const SizedBox(height: 16),
            Text(_error!,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, height: 1.7)),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _reload,
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _header() {
    final s = _s;
    final now = DateTime.now();
    final ramadan = s != null && s.ramadan;
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(ramadan ? 'رمضان مبارك 🌙' : 'السلام عليكم',
              style:
                  const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(
            '${kDayNames[now.weekday - 1]}  ${now.day}/${now.month}/${now.year}',
            style: const TextStyle(color: Colors.white70, fontSize: 15),
          ),
        ],
      ),
    );
  }

  Widget _countdown(PlanItem? next) {
    if (next == null) {
      return const GlassCard(
        child: Row(
          children: [
            Text('🤲', style: TextStyle(fontSize: 28)),
            SizedBox(width: 12),
            Expanded(
              child: Text('أتممتَ صلوات اليوم… تقبّل الله طاعتك',
                  style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      );
    }
    final diff = next.time.difference(DateTime.now());
    final h = diff.inHours;
    final m = diff.inMinutes % 60;
    return GlassCard(
      highlight: AppColors.gold,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('الصلاة القادمة', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 6),
          Row(
            children: [
              Text(next.title,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w800)),
              const Spacer(),
              Text(fmt(next.time),
                  style: const TextStyle(
                      fontSize: 22,
                      color: AppColors.gold,
                      fontWeight: FontWeight.w800)),
            ],
          ),
          const SizedBox(height: 6),
          Text('بعد $h ساعة و $m دقيقة',
              style: const TextStyle(color: Colors.white70)),
        ],
      ),
    );
  }

  Widget _progress(int done) {
    final progress = _items.isEmpty ? 0.0 : done / _items.length;
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('إنجاز اليوم',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              const Spacer(),
              Text('$done / ${_items.length}',
                  style: const TextStyle(
                      color: AppColors.gold, fontWeight: FontWeight.w700)),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              color: AppColors.gold,
              backgroundColor: Colors.white24,
            ),
          ),
        ],
      ),
    );
  }

  Widget _quote() {
    final q = quoteOfDay(DateTime.now());
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.format_quote_rounded, color: AppColors.gold),
              SizedBox(width: 6),
              Text('قول اليوم',
                  style: TextStyle(
                      color: AppColors.gold, fontWeight: FontWeight.w700)),
            ],
          ),
          const SizedBox(height: 10),
          Text(q.text, style: const TextStyle(fontSize: 17, height: 1.8)),
          const SizedBox(height: 6),
          Text(q.source,
              style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _tile(PlanItem it, bool last) {
    final s = _s;
    final checked = _done[it.id] ?? false;
    final slot = it.slot;
    final hasAudio = slot != null && s != null && s.audioFor(slot) != null;

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            width: 56,
            child: Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Text(fmt(it.time),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 13)),
            ),
          ),
          Column(
            children: [
              Container(
                width: 14,
                height: 14,
                margin: const EdgeInsets.only(top: 22),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: checked ? it.color : Colors.transparent,
                  border: Border.all(color: it.color, width: 2),
                ),
              ),
              Expanded(
                child: Container(
                  width: 2,
                  color: last ? Colors.transparent : Colors.white24,
                ),
              ),
            ],
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: GlassCard(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                onTap: () => _toggle(it, !checked),
                child: Row(
                  children: [
                    Text(it.emoji, style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        it.title,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          decoration:
                              checked ? TextDecoration.lineThrough : null,
                        ),
                      ),
                    ),
                    if (slot != null)
                      IconButton(
                        tooltip:
                            hasAudio ? 'تشغيل الملف المرفوع' : 'فتح بحث يوتيوب',
                        icon: Icon(hasAudio
                            ? Icons.play_circle_fill_rounded
                            : Icons.music_note_rounded),
                        onPressed: () {
                          final ss = _s;
                          if (ss != null) playSlotOrOpen(ss, slot);
                        },
                      ),
                    Icon(
                      checked
                          ? Icons.check_circle_rounded
                          : Icons.radio_button_unchecked,
                      color: it.color,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
