import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';

import 'prayer_service.dart';
import 'settings.dart';
import 'stats.dart';

/// مشغّل الصوت الموحّد للتطبيق: الأذان والأغاني والتجارب
class AudioHub {
  static final AudioPlayer _player = AudioPlayer();

  /// المسار الذي يُشغَّل حالياً (null إذا لا شيء)
  static final ValueNotifier<String?> nowPlaying = ValueNotifier<String?>(null);

  static String nameOf(String path) => File(path).uri.pathSegments.last;

  /// يختار ملفاً صوتياً من الهاتف وينسخه إلى مساحة التطبيق
  static Future<String?> pickAndStore(Settings s) async {
    final res = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (res == null || res.files.isEmpty) return null;
    final src = res.files.first.path;
    if (src == null) return null;

    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}/audio')..createSync(recursive: true);
    final dest =
        '${dir.path}/${DateTime.now().millisecondsSinceEpoch}_${nameOf(src)}';
    await File(src).copy(dest);

    await s.setAudioLibrary([...s.audioLibrary, dest]);
    return dest;
  }

  static Future<void> play(String path, double volume) async {
    try {
      await _player.stop();
      await _player.setFilePath(path);
      await _player.setVolume(volume);
      nowPlaying.value = path;
      _player.play().whenComplete(() {
        if (nowPlaying.value == path) nowPlaying.value = null;
      });
    } catch (_) {
      nowPlaying.value = null;
    }
  }

  static Future<void> playSlot(Settings s, String slot) async {
    final path = s.audioFor(slot);
    if (path == null) return;
    await play(path, s.volume);
  }

  static Future<void> stop() async {
    await _player.stop();
    nowPlaying.value = null;
  }

  static Future<void> setVolume(double v) => _player.setVolume(v);

  /// يحذف الملف من الهاتف ويلغي ربطه بأي خانة
  static Future<void> delete(Settings s, String path) async {
    if (nowPlaying.value == path) await stop();
    for (final slot in ['adhan', 'gym', 'study', 'walk']) {
      if (s.audioFor(slot) == path) await s.setAudioFor(slot, null);
    }
    await s.setAudioLibrary(s.audioLibrary.where((x) => x != path).toList());
    try {
      final f = File(path);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}

/// يراقب الوقت أثناء فتح التطبيق ويشغّل الأذان المرفوع عند دخول وقت الصلاة
class AdhanWatcher {
  static String? _lastKey;

  static Future<void> check(Settings s) async {
    if (!s.adhan) return;
    final now = DateTime.now();
    try {
      final pt = await PrayerService.getTimes(now, s, preferCache: true);
      for (final e in pt.times.entries) {
        if (e.value.hour == now.hour && e.value.minute == now.minute) {
          final key = '${dayKeyOf(now)}-${e.key}';
          if (_lastKey == key) return;
          _lastKey = key;
          await AudioHub.playSlot(s, 'adhan');
          return;
        }
      }
    } catch (_) {}
  }
}
