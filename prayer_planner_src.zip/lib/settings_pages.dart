import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import 'audio_service.dart';
import 'config.dart';
import 'notification_service.dart';
import 'permissions_service.dart';
import 'settings.dart';
import 'theme.dart';
import 'widgets.dart';

// ============================================================
// الإعدادات
// ============================================================
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  Settings? _s;
  double? _preDraft;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await Settings.load();
    if (mounted) setState(() => _s = s);
  }

  void _changed() {
    notifyDataChanged();
    if (mounted) setState(() {});
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Widget _section(String title, List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: GlassCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(
                    color: AppColors.gold,
                    fontWeight: FontWeight.w800,
                    fontSize: 16)),
            const SizedBox(height: 6),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _cityPicker(Settings s) {
    final names = [for (final c in kCities) c.name];
    if (!names.contains(s.cityName)) names.insert(0, s.cityName);
    return DropdownButtonFormField<String>(
      value: s.cityName,
      decoration: const InputDecoration(labelText: 'المدينة'),
      dropdownColor: const Color(0xFF13294B),
      items: [
        for (final n in names) DropdownMenuItem(value: n, child: Text(n)),
      ],
      onChanged: (v) {
        if (v == null) return;
        final match = kCities.where((c) => c.name == v);
        if (match.isEmpty) return;
        final c = match.first;
        s.setLocation(c.name, c.lat, c.lng).then((_) => _changed());
      },
    );
  }

  Future<void> _useGps(Settings s) async {
    await requestSpec(kPermSpecs[2]);
    final pos = await currentPosition();
    if (pos == null) {
      _snack('تعذّر تحديد الموقع. فعّل GPS وأعطِ صلاحية الموقع.');
      return;
    }
    await s.setLocation('موقعي الحالي', pos.latitude, pos.longitude);
    _changed();
    _snack('تم ضبط الموقع');
  }

  Widget _timeTile(Settings s, String label, TimeOfDay t, String key) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(label),
      trailing: Text(fmtTod(t),
          style: const TextStyle(
              color: AppColors.gold, fontWeight: FontWeight.w700, fontSize: 16)),
      onTap: () async {
        final picked = await showTimePicker(context: context, initialTime: t);
        if (picked == null) return;
        await s.setTime(key, picked);
        _changed();
      },
    );
  }

  Widget _switch(Settings s, String title, String sub, bool value,
      Future<void> Function(bool) save) {
    return SwitchListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(title),
      subtitle: Text(sub, style: const TextStyle(color: Colors.white60)),
      value: value,
      onChanged: (v) {
        save(v).then((_) => _changed());
      },
    );
  }

  Future<void> _addTask(Settings s) async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('مهمة جديدة'),
        content: TextField(
          controller: ctrl,
          decoration: const InputDecoration(hintText: 'مثال: قراءة كتاب'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('التالي')),
        ],
      ),
    );
    if (ok != true || ctrl.text.trim().isEmpty) return;
    if (!mounted) return;
    final t = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 20, minute: 0),
    );
    if (t == null) return;
    await s.saveCustomTasks([
      ...s.customTasks,
      CustomTask(
        id: '${DateTime.now().millisecondsSinceEpoch}',
        title: ctrl.text.trim(),
        emoji: '⭐',
        hour: t.hour,
        minute: t.minute,
      ),
    ]);
    _changed();
  }

  Future<void> _deleteTask(Settings s, CustomTask task) async {
    await s.saveCustomTasks(
        s.customTasks.where((x) => x.id != task.id).toList());
    _changed();
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    if (s == null) return const Center(child: CircularProgressIndicator());

    const days = [
      (7, 'أحد'),
      (1, 'اثنين'),
      (2, 'ثلاثاء'),
      (3, 'أربعاء'),
      (4, 'خميس'),
      (5, 'جمعة'),
      (6, 'سبت'),
    ];

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      children: [
        const PageHeader(title: 'الإعدادات', subtitle: 'خصّص التطبيق كما تحب'),

        _section('الموقع وأوقات الصلاة', [
          const SizedBox(height: 6),
          _cityPicker(s),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => _useGps(s),
            icon: const Icon(Icons.my_location),
            label: const Text('تحديد موقعي بـ GPS'),
          ),
        ]),

        _section('الروتين اليومي', [
          _timeTile(s, 'وقت الجيم', s.gymTime, 'gymTime'),
          _timeTile(s, 'وقت الشاور', s.showerTime, 'showerTime'),
          _timeTile(s, 'وقت السوق', s.marketTime, 'marketTime'),
          _timeTile(s, 'ورد القرآن', s.quranTime, 'quranTime'),
          const SizedBox(height: 8),
          const Text('أيام الجيم', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final d in days)
                FilterChip(
                  label: Text(d.$2),
                  selected: s.gymDays.contains(d.$1),
                  onSelected: (sel) {
                    final list = s.gymDays.toList();
                    if (sel) {
                      list.add(d.$1);
                    } else {
                      list.remove(d.$1);
                    }
                    s.setGymDays(list).then((_) => _changed());
                  },
                ),
            ],
          ),
        ]),

        _section('الصلاة والتنبيهات', [
          _switch(s, 'الوضع الرمضاني', 'سحور وإفطار وتراويح بدل الفطور والمشروبات',
              s.ramadan, (v) => s.setFlag('ramadan', v)),
          _switch(s, 'الأذان', 'تشغيل الأذان المرفوع عند وقت كل صلاة',
              s.adhan, (v) => s.setFlag('adhan', v)),
          _switch(s, 'أذكار الصباح والمساء', 'تذكير بعد الفجر وبعد العصر',
              s.adhkar, (v) => s.setFlag('adhkar', v)),
          _switch(s, 'تذكير ورد القرآن', 'تذكير يومي في الوقت المحدد',
              s.quranReminder, (v) => s.setFlag('quranOn', v)),
          const SizedBox(height: 8),
          Text('تنبيه قبل الصلاة: ${_preDraft?.round() ?? s.preMinutes} دقيقة',
              style: const TextStyle(color: Colors.white70)),
          Slider(
            value: _preDraft ?? s.preMinutes.toDouble(),
            min: 0,
            max: 30,
            divisions: 6,
            label: '${_preDraft?.round() ?? s.preMinutes}',
            onChanged: (v) => setState(() => _preDraft = v),
            onChangeEnd: (v) {
              s.setPreMinutes(v.round()).then((_) {
                _preDraft = null;
                _changed();
              });
            },
          ),
        ]),

        _section('المظهر', [
          const SizedBox(height: 6),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (var i = 0; i < kPalettes.length; i++)
                GestureDetector(
                  onTap: () {
                    kPaletteIndex.value = i;
                    s.setPalette(i).then((_) => _changed());
                  },
                  child: Column(
                    children: [
                      Container(
                        width: 84,
                        height: 56,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: kPalettes[i].day),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: s.palette == i
                                ? AppColors.gold
                                : Colors.white24,
                            width: s.palette == i ? 3 : 1,
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      SizedBox(
                        width: 84,
                        child: Text(kPalettes[i].name,
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 11)),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ]),

        _section('الصوت', [
          const SizedBox(height: 6),
          Text('مستوى الصوت: ${(s.volume * 100).round()}%',
              style: const TextStyle(color: Colors.white70)),
          Slider(
            value: s.volume,
            min: 0,
            max: 1,
            onChanged: (v) {
              s.setVolume(v).then((_) => AudioHub.setVolume(v));
              setState(() {});
            },
          ),
          const SizedBox(height: 4),
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AudioLibraryPage()),
            ),
            icon: const Icon(Icons.library_music),
            label: const Text('المكتبة الصوتية (رفع وضبط الملفات)'),
          ),
        ]),

        _section('المهام الشخصية', [
          for (final t in s.customTasks)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Text(t.emoji, style: const TextStyle(fontSize: 22)),
              title: Text(t.title),
              subtitle: Text(
                  '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}'),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () => _deleteTask(s, t),
              ),
            ),
          const SizedBox(height: 4),
          OutlinedButton.icon(
            onPressed: () => _addTask(s),
            icon: const Icon(Icons.add),
            label: const Text('إضافة مهمة'),
          ),
        ]),

        _section('الصلاحيات والاختبار', [
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PermissionsPage()),
            ),
            icon: const Icon(Icons.verified_user),
            label: const Text('الصلاحيات (الإشعارات والصوت والموقع)'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () async {
              await NotificationService.showNow(
                title: '✅ الإشعارات تعمل',
                body: 'هذا إشعار تجريبي من مخطط اليوم',
              );
              _snack('أُرسل إشعار تجريبي');
            },
            icon: const Icon(Icons.notifications_active_outlined),
            label: const Text('تجربة إشعار الآن'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () async {
              if (s.audioFor('adhan') == null) {
                _snack('ارفع ملف الأذان أولاً من المكتبة الصوتية');
                return;
              }
              await AudioHub.playSlot(s, 'adhan');
            },
            icon: const Icon(Icons.campaign_outlined),
            label: const Text('تجربة الأذان'),
          ),
        ]),
      ],
    );
  }
}

// ============================================================
// المكتبة الصوتية
// ============================================================
class AudioLibraryPage extends StatefulWidget {
  const AudioLibraryPage({super.key});

  @override
  State<AudioLibraryPage> createState() => _AudioLibraryPageState();
}

class _AudioLibraryPageState extends State<AudioLibraryPage> {
  Settings? _s;

  @override
  void initState() {
    super.initState();
    Settings.load().then((s) {
      if (mounted) setState(() => _s = s);
    });
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _upload() async {
    final s = _s;
    if (s == null) return;
    final path = await AudioHub.pickAndStore(s);
    if (!mounted) return;
    setState(() {});
    _snack(path == null ? 'لم يتم اختيار ملف' : 'تمت إضافة الملف');
  }

  Future<void> _delete(Settings s, String path) async {
    await AudioHub.delete(s, path);
    if (mounted) setState(() {});
  }

  Widget _fileCard(Settings s, String path) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.audiotrack, color: AppColors.gold),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(AudioHub.nameOf(path),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                ),
                ValueListenableBuilder<String?>(
                  valueListenable: AudioHub.nowPlaying,
                  builder: (context, playing, child) {
                    final isPlaying = playing == path;
                    return IconButton(
                      icon: Icon(isPlaying
                          ? Icons.stop_circle_outlined
                          : Icons.play_circle_outline),
                      onPressed: () {
                        if (isPlaying) {
                          AudioHub.stop();
                        } else {
                          AudioHub.play(path, s.volume);
                        }
                      },
                    );
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => _delete(s, path),
                ),
              ],
            ),
            const SizedBox(height: 4),
            const Text('اربط الملف بـ:',
                style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final e in kAudioSlots.entries)
                  FilterChip(
                    label: Text(e.value),
                    selected: s.audioFor(e.key) == path,
                    onSelected: (sel) async {
                      await s.setAudioFor(e.key, sel ? path : null);
                      if (mounted) setState(() {});
                    },
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    return DetailScaffold(
      title: 'المكتبة الصوتية',
      child: s == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
              children: [
                const PageHeader(
                  title: 'ملفاتك الصوتية',
                  subtitle: 'ارفع الأذان والأغاني ثم اربط كل ملف بخانته',
                ),
                FilledButton.icon(
                  onPressed: _upload,
                  icon: const Icon(Icons.upload_file),
                  label: const Text('رفع ملف صوتي من الهاتف'),
                ),
                const SizedBox(height: 16),
                if (s.audioLibrary.isEmpty)
                  const GlassCard(
                    child: Text('لا توجد ملفات بعد. ارفع ملف الأذان أو أغانيك.',
                        textAlign: TextAlign.center),
                  ),
                for (final path in s.audioLibrary) _fileCard(s, path),
              ],
            ),
    );
  }
}

// ============================================================
// الصلاحيات
// ============================================================
class PermissionsPage extends StatefulWidget {
  const PermissionsPage({super.key});

  @override
  State<PermissionsPage> createState() => _PermissionsPageState();
}

class _PermissionsPageState extends State<PermissionsPage>
    with WidgetsBindingObserver {
  final Map<int, bool> _granted = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    for (var i = 0; i < kPermSpecs.length; i++) {
      _granted[i] = await isSpecGranted(kPermSpecs[i]);
    }
    if (mounted) setState(() {});
  }

  Future<void> _request(int i) async {
    await requestSpec(kPermSpecs[i]);
    await _refresh();
  }

  Future<void> _requestAll() async {
    for (var i = 0; i < kPermSpecs.length; i++) {
      if (_granted[i] != true) await requestSpec(kPermSpecs[i]);
    }
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return DetailScaffold(
      title: 'الصلاحيات',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        children: [
          const PageHeader(
            title: 'الصلاحيات',
            subtitle: 'التطبيق يحتاجها ليعمل بشكل كامل',
          ),
          FilledButton.icon(
            onPressed: _requestAll,
            icon: const Icon(Icons.done_all),
            label: const Text('طلب كل الصلاحيات'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => openAppSettings(),
            icon: const Icon(Icons.settings),
            label: const Text('فتح إعدادات التطبيق (إن رُفض إذن نهائياً)'),
          ),
          const SizedBox(height: 16),
          for (var i = 0; i < kPermSpecs.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: GlassCard(
                child: Row(
                  children: [
                    Icon(
                      (_granted[i] ?? false)
                          ? Icons.check_circle
                          : Icons.cancel,
                      color: (_granted[i] ?? false)
                          ? AppColors.green
                          : AppColors.rose,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(kPermSpecs[i].title,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700)),
                          Text(kPermSpecs[i].why,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 13)),
                        ],
                      ),
                    ),
                    if (_granted[i] != true)
                      TextButton(
                        onPressed: () => _request(i),
                        child: const Text('طلب'),
                      ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
