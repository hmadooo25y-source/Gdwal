// ============================================================
// إعدادات التطبيق — عدّل هنا حسب مكانك وتفضيلاتك
// ============================================================

// موقعك (القدس افتراضياً). غيّره لمدينتك.
const double kLatitude = 31.7683;
const double kLongitude = 35.2137;

// طريقة حساب أوقات الصلاة (3 = Muslim World League)
const int kCalcMethod = 3;

const String kTimeZone = 'Asia/Jerusalem';

// أيام الجيم (1 = الاثنين ... 7 = الأحد): الأحد، الثلاثاء، الخميس
const List<int> kGymWeekdays = [7, 2, 4];

// وقت بداية الجيم
const int kGymHour = 6;
const int kGymMinute = 0;

// وقت إشعار "قول مأثور اليوم"
const int kDailyQuoteHour = 7;
const int kDailyQuoteMinute = 30;

class Song {
  final String title;
  final String query;
  const Song(this.title, this.query);

  // يفتح نتائج بحث YouTube (لا نضمّن ملفات صوتية محمية بحقوق النشر)
  String get url =>
      'https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent(query)}';
}

const Map<String, Song> kSongs = {
  'gym': Song('حماس للتمرين', 'أغاني حماسية للرياضة والجيم'),
  'study': Song('تركيز للدراسة', 'موسيقى تركيز للدراسة'),
  'walk': Song('نشيد للمشي', 'أناشيد حماسية للمشي'),
};
