// ============================================================
// إعدادات ثابتة للتطبيق
// ============================================================

const String kTimeZone = 'Asia/Jerusalem';

// طريقة حساب أوقات الصلاة (3 = Muslim World League)
const int kCalcMethod = 3;

// يُضبط تلقائياً من GitHub Actions عند وجود ملف sounds/adhan.mp3 في المستودع
const bool kHasBundledAdhan = bool.fromEnvironment('HAS_ADHAN');

const int kDailyQuoteHour = 7;
const int kDailyQuoteMinute = 30;

class City {
  final String name;
  final double lat;
  final double lng;
  const City(this.name, this.lat, this.lng);
}

const List<City> kCities = [
  City('القدس', 31.7683, 35.2137),
  City('رام الله', 31.9038, 35.2034),
  City('نابلس', 32.2211, 35.2544),
  City('غزة', 31.5017, 34.4668),
  City('عمّان', 31.9454, 35.9284),
  City('القاهرة', 30.0444, 31.2357),
  City('الرياض', 24.7136, 46.6753),
  City('دبي', 25.2048, 55.2708),
];

// الخانات الصوتية التي يمكن ربط ملف صوتي بها
const Map<String, String> kAudioSlots = {
  'adhan': 'الأذان',
  'gym': 'أغنية الجيم',
  'study': 'أغنية الدراسة',
  'walk': 'أغنية المشي',
};
