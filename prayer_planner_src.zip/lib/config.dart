// ============================================================
// إعدادات التطبيق — عدّل هنا حسب مكانك وتفضيلاتك
// ============================================================

// موقعك (القدس افتراضياً). غيّره لمدينتك.
const double kLatitude = 31.7683;
const double kLongitude = 35.2137;

// طريقة حساب أوقات الصلاة في Aladhan API
// 3 = Muslim World League
const int kCalcMethod = 3;

const String kTimeZone = 'Asia/Jerusalem';

// أيام الجيم (1 = الاثنين ... 7 = الأحد)
const List<int> kGymWeekdays = [7, 2, 4]; // الأحد، الثلاثاء، الخميس

// وقت بداية الجيم (ساعة:دقيقة) — 6 صباحاً حسب طلبك
const int kGymHour = 6;
const int kGymMinute = 0;

class Song {
  final String title;
  final String query;
  const Song(this.title, this.query);

  // يفتح نتائج بحث YouTube (لا نحتاج لتضمين ملفات صوتية محمية)
  String get url =>
      'https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent(query)}';
}

const Map<String, Song> kSongs = {
  'prayer': Song('نشيد هادئ قبل الصلاة', 'أناشيد إسلامية هادئة'),
  'gym': Song('حماس للتمرين', 'أغاني حماسية للرياضة والجيم'),
  'study': Song('تركيز للدراسة', 'موسيقى تركيز للدراسة'),
  'walk': Song('نشيد للمشي', 'أناشيد حماسية للمشي'),
};
