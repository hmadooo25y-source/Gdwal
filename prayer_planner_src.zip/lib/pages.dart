import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'content.dart';
import 'notification_service.dart';
import 'prayer_service.dart';
import 'routine.dart';
import 'scheduler.dart';
import 'theme.dart';
import 'widgets.dart';

// ============================================================
// اليوم
// ============================================================
class TodayPage extends StatefulWidget {
  const TodayPage({super.key});

  @override
  State<TodayPage> createState() => _TodayPageState();
}

class _TodayPageState extends State<TodayPage> {
  bool _loading = true;
  String? _error;
  List<PlanItem> _items = [];
  Map<String, bool> _done = {};
  SharedPreferences? _prefs;
  Timer? _ticker;

  String get _dayKey {
    final n = DateTime.now();
    return '${n.year}-${n.month}-${n.day}';
  }

  @override
  void initState() {
    super.initState();
    _load();
    _ticker = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    if (!_loading) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      _prefs = prefs;
      final today = DateTime.now();
      final prayers = await PrayerService.getTimes(today, prefs);
      final items = buildDay(today, prayers);
      final done = {
        for (final i in items) i.id: prefs.getBool('$_dayKey-${i.id}') ?? false,
      };
      if (!mounted) return;
      setState(() {
        _items = items;
        _done = done;
        _loading = false;
      });
      // الإشعارات تعمل بالخلفية ولا تؤثر على عرض الجدول
      NotificationService.requestPermissions();
      scheduleWeek(prefs);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'تعذّر تحميل أوقات الصلاة.\nتأكد من اتصال الإنترنت ثم أعد المحاولة.';
      });
    }
  }

  void _toggle(String id, bool value) {
    setState(() => _done[id] = value);
    _prefs?.setBool('$_dayKey-$id', value);
  }

  PlanItem? _nextPrayer() {
    final now = DateTime.now();
    for (final it in _items) {
      if (it.isPrayer && it.time.isAfter(now)) return it;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) return _errorView();

    final done = _done.values.where((v) => v).length;
    final progress = _items.isEmpty ? 0.0 : done / _items.length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      children: [
        _header(),
        _countdownCard(_nextPrayer()),
        const SizedBox(height: 12),
        _progressCard(done, progress),
        const SizedBox(height: 12),
        _quoteCard(),
        const SizedBox(height: 20),
        for (var i = 0; i < _items.length; i++)
          _timelineTile(_items[i], i == _items.length - 1),
      ],
    );
  }

  Widget _errorView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_rounded, size: 56, color: AppColors.gold),
            const SizedBox(height: 16),
            Text(_error!,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, height: 1.7)),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _load,
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _header() {
    final now = DateTime.now();
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('السلام عليكم',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(
            '${kDayNames[now.weekday - 1]}  ${now.day}/${now.month}/${now.year}',
            style: const TextStyle(color: Colors.white70, fontSize: 15),
          ),
        ],
      ),
    );
  }

  Widget _countdownCard(PlanItem? next) {
    if (next == null) {
      return const GlassCard(
        child: Row(
          children: [
            Text('🤲', style: TextStyle(fontSize: 28)),
            SizedBox(width: 12),
            Expanded(
              child: Text('أتممتَ صلوات اليوم… تقبّل الله طاعتك',
                  style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      );
    }
    final diff = next.time.difference(DateTime.now());
    final h = diff.inHours;
    final m = diff.inMinutes % 60;
    return GlassCard(
      highlight: AppColors.gold,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('الصلاة القادمة',
              style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 6),
          Row(
            children: [
              Text(next.title,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w800)),
              const Spacer(),
              Text(fmt(next.time),
                  style: const TextStyle(
                      fontSize: 22,
                      color: AppColors.gold,
                      fontWeight: FontWeight.w800)),
            ],
          ),
          const SizedBox(height: 6),
          Text('بعد $h ساعة و $m دقيقة',
              style: const TextStyle(color: Colors.white70)),
        ],
      ),
    );
  }

  Widget _progressCard(int done, double progress) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('إنجاز اليوم',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              const Spacer(),
              Text('$done / ${_items.length}',
                  style: const TextStyle(
                      color: AppColors.gold, fontWeight: FontWeight.w700)),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              color: AppColors.gold,
              backgroundColor: Colors.white24,
            ),
          ),
        ],
      ),
    );
  }

  Widget _quoteCard() {
    final q = quoteOfDay(DateTime.now());
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.format_quote_rounded, color: AppColors.gold),
              SizedBox(width: 6),
              Text('قول اليوم',
                  style: TextStyle(
                      color: AppColors.gold, fontWeight: FontWeight.w700)),
            ],
          ),
          const SizedBox(height: 10),
          Text(q.text, style: const TextStyle(fontSize: 17, height: 1.8)),
          const SizedBox(height: 6),
          Text(q.source,
              style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _timelineTile(PlanItem it, bool last) {
    final checked = _done[it.id] ?? false;
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            width: 56,
            child: Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Text(fmt(it.time),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 13)),
            ),
          ),
          Column(
            children: [
              Container(
                width: 14,
                height: 14,
                margin: const EdgeInsets.only(top: 22),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: checked ? it.color : Colors.transparent,
                  border: Border.all(color: it.color, width: 2),
                ),
              ),
              Expanded(
                child: Container(
                  width: 2,
                  color: last ? Colors.transparent : Colors.white24,
                ),
              ),
            ],
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: GlassCard(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                onTap: () => _toggle(it.id, !checked),
                child: Row(
                  children: [
                    Text(it.emoji, style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        it.title,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          decoration:
                              checked ? TextDecoration.lineThrough : null,
                        ),
                      ),
                    ),
                    if (it.song != null)
                      IconButton(
                        tooltip: it.song!.title,
                        icon: const Icon(Icons.music_note_rounded),
                        onPressed: () => launchUrl(
                          Uri.parse(it.song!.url),
                          mode: LaunchMode.externalApplication,
                        ),
                      ),
                    Icon(
                      checked
                          ? Icons.check_circle_rounded
                          : Icons.radio_button_unchecked,
                      color: it.color,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// الحِكَم
// ============================================================
class QuotesPage extends StatelessWidget {
  const QuotesPage({super.key});

  void _copy(BuildContext context, AliQuote q) {
    Clipboard.setData(ClipboardData(text: '${q.text}\n— ${q.source}'));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم نسخ القول')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final today = quoteOfDay(DateTime.now());
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      children: [
        const PageHeader(
          title: 'الحِكَم',
          subtitle: 'من أقوال الإمام علي بن أبي طالب (ع)',
        ),
        GlassCard(
          padding: const EdgeInsets.all(20),
          highlight: AppColors.gold,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('قول اليوم',
                  style: TextStyle(
                      color: AppColors.gold, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              Text(today.text,
                  style: const TextStyle(fontSize: 20, height: 1.9)),
              const SizedBox(height: 8),
              Text(today.source,
                  style: const TextStyle(color: Colors.white60, fontSize: 12)),
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton.icon(
                  onPressed: () => _copy(context, today),
                  icon: const Icon(Icons.copy_rounded, size: 18),
                  label: const Text('نسخ'),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        for (final q in kAliQuotes)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: GlassCard(
              onTap: () => _copy(context, q),
              child: Text(q.text,
                  style: const TextStyle(fontSize: 16, height: 1.8)),
            ),
          ),
      ],
    );
  }
}

// ============================================================
// الأعمال
// ============================================================
class DeedsPage extends StatelessWidget {
  const DeedsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      children: [
        const PageHeader(
          title: 'أعمال تزيد الحسنات',
          subtitle: 'اختر منها كل يوم ما يتيسر لك',
        ),
        for (var i = 0; i < kGoodDeeds.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: GlassCard(
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 16,
                    backgroundColor: AppColors.emerald,
                    child: Text('${i + 1}',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(kGoodDeeds[i],
                        style: const TextStyle(fontSize: 15, height: 1.5)),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

// ============================================================
// اللبس
// ============================================================
class OutfitPage extends StatelessWidget {
  const OutfitPage({super.key});

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now().weekday - 1;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      children: [
        const PageHeader(
          title: 'ألوان اللبس',
          subtitle: 'اختيار منسجم لكل يوم من أيام الأسبوع',
        ),
        for (var i = 0; i < kOutfits.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: GlassCard(
              highlight: i == today ? AppColors.gold : null,
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${kDayNames[i]}${i == today ? '  ·  اليوم' : ''}',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                            color: i == today ? AppColors.gold : null,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(kOutfits[i].name,
                            style: const TextStyle(fontSize: 15)),
                        Text(kOutfits[i].description,
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 13)),
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      for (final c in kOutfits[i].swatches)
                        Container(
                          width: 26,
                          height: 26,
                          margin: const EdgeInsets.only(left: 6),
                          decoration: BoxDecoration(
                            color: c,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white54),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

// ============================================================
// الطعام
// ============================================================
class FoodPage extends StatelessWidget {
  const FoodPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      children: [
        const PageHeader(
          title: 'طعام صحي',
          subtitle: 'اقتراحات متوازنة لفطورك ومشروباتك ووجباتك',
        ),
        for (final section in kFood.entries) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 8, 4, 8),
            child: Text(section.key,
                style: const TextStyle(
                    color: AppColors.gold,
                    fontWeight: FontWeight.w800,
                    fontSize: 18)),
          ),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final item in section.value)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Text('•  $item',
                        style: const TextStyle(fontSize: 15, height: 1.5)),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
      ],
    );
  }
}
