import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'content.dart';
import 'notification_service.dart';
import 'settings.dart';
import 'stats.dart';
import 'theme.dart';
import 'widgets.dart';

// ---------- الأعمال المنجزة لكل يوم ----------
List<int> deedsOf(Settings s, DateTime d) =>
    (s.p.getStringList('deeds-${dayKeyOf(d)}') ?? []).map(int.parse).toList();

Future<void> setDeeds(Settings s, DateTime d, List<int> v) =>
    s.p.setStringList('deeds-${dayKeyOf(d)}', [for (final x in v) '$x']);

// ============================================================
// القائمة الرئيسية "المزيد"
// ============================================================
class MorePage extends StatelessWidget {
  const MorePage({super.key});

  Widget _tile(BuildContext c, String title, String sub, IconData icon,
      Widget page) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassCard(
        onTap: () =>
            Navigator.push(c, MaterialPageRoute(builder: (_) => page)),
        child: Row(
          children: [
            Icon(icon, color: AppColors.gold, size: 28),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700)),
                  Text(sub,
                      style:
                          const TextStyle(color: Colors.white70, fontSize: 13)),
                ],
              ),
            ),
            const Icon(Icons.chevron_left_rounded),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      children: [
        const PageHeader(title: 'المزيد', subtitle: 'أدوات ومحتوى إضافي'),
        _tile(context, 'أعمال تزيد الحسنات', 'سجّل ما أنجزته اليوم',
            Icons.volunteer_activism, const DeedsPage()),
        _tile(context, 'ألوان اللبس', 'اقتراحات منسجمة لكل يوم',
            Icons.checkroom_outlined, const OutfitPage()),
        _tile(context, 'طعام صحي', 'فطور ومشروبات ووجبات متوازنة',
            Icons.restaurant_outlined, const FoodPage()),
        _tile(context, 'مؤقت التركيز', 'بومودورو: 25 دقيقة تركيز و5 استراحة',
            Icons.timer_outlined, const PomodoroPage()),
      ],
    );
  }
}

// ============================================================
// الإنجاز والإحصائيات
// ============================================================
class StatsPage extends StatefulWidget {
  const StatsPage({super.key});

  @override
  State<StatsPage> createState() => _StatsPageState();
}

class _StatsPageState extends State<StatsPage> {
  Settings? _s;

  @override
  void initState() {
    super.initState();
    kSummaryVersion.addListener(_refresh);
    Settings.load().then((s) {
      if (mounted) setState(() => _s = s);
    });
  }

  @override
  void dispose() {
    kSummaryVersion.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Widget _statCard(String emoji, String value, String label) {
    return GlassCard(
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 26)),
          const SizedBox(height: 6),
          Text(value,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          Text(label, style: const TextStyle(color: Colors.white70)),
        ],
      ),
    );
  }

  Widget _bar(Settings s, DateTime d) {
    final sum = readSummary(s.p, d);
    final r = sum?.ratio ?? 0;
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Text(sum == null ? '-' : '${(r * 100).round()}%',
            style: const TextStyle(fontSize: 10)),
        const SizedBox(height: 4),
        AnimatedContainer(
          duration: const Duration(milliseconds: 400),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          height: 8 + 80 * r,
          decoration: BoxDecoration(
            color: r >= 0.5 ? AppColors.gold : AppColors.sky,
            borderRadius: BorderRadius.circular(6),
          ),
        ),
        const SizedBox(height: 4),
        Text('${d.day}', style: const TextStyle(fontSize: 11)),
      ],
    );
  }

  Widget _dayCell(Settings s, DateTime day, bool isToday) {
    final sum = readSummary(s.p, day);
    final r = sum?.ratio ?? 0;
    final Color color;
    if (r >= 0.8) {
      color = AppColors.gold;
    } else if (r >= 0.5) {
      color = AppColors.emerald;
    } else if (r > 0) {
      color = AppColors.sky.withOpacity(0.5);
    } else {
      color = Colors.white10;
    }
    return Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(10),
        border: isToday ? Border.all(color: Colors.white, width: 2) : null,
      ),
      child: Text('${day.day}',
          style: const TextStyle(fontWeight: FontWeight.w600)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    if (s == null) return const Center(child: CircularProgressIndicator());

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final week = [
      for (var i = 6; i >= 0; i--) today.subtract(Duration(days: i)),
    ];
    final streak = streakOf(s.p, now);
    final monthStart = DateTime(now.year, now.month, 1);
    final daysInMonth = DateTime(now.year, now.month + 1, 0).day;
    final offset = monthStart.weekday % 7; // الأحد = 0
    var monthDeeds = 0;
    for (var d = 1; d <= now.day; d++) {
      monthDeeds += deedsOf(s, DateTime(now.year, now.month, d)).length;
    }
    const labels = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      children: [
        const PageHeader(
            title: 'الإنجاز', subtitle: 'تابع تقدمك اليومي والشهري'),
        Row(
          children: [
            Expanded(child: _statCard('🔥', '$streak', 'أيام متتالية')),
            const SizedBox(width: 10),
            Expanded(child: _statCard('🤍', '$monthDeeds', 'أعمال هذا الشهر')),
          ],
        ),
        const SizedBox(height: 12),
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('آخر 7 أيام',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              SizedBox(
                height: 130,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [for (final d in week) Expanded(child: _bar(s, d))],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('شهر ${now.month}/${now.year}',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Row(
                children: [
                  for (final l in labels)
                    Expanded(
                      child: Text(l,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 10, color: Colors.white70)),
                    ),
                ],
              ),
              const SizedBox(height: 6),
              GridView.count(
                crossAxisCount: 7,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 6,
                crossAxisSpacing: 6,
                children: [
                  for (var i = 0; i < offset; i++) const SizedBox(),
                  for (var d = 1; d <= daysInMonth; d++)
                    _dayCell(s, DateTime(now.year, now.month, d),
                        d == now.day),
                ],
              ),
              const SizedBox(height: 10),
              const Wrap(
                spacing: 12,
                children: [
                  Text('🟡 80%+', style: TextStyle(fontSize: 12)),
                  Text('🟢 50%+', style: TextStyle(fontSize: 12)),
                  Text('🔵 أقل', style: TextStyle(fontSize: 12)),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ============================================================
// الحِكَم
// ============================================================
class QuotesPage extends StatelessWidget {
  const QuotesPage({super.key});

  void _copy(BuildContext context, AliQuote q) {
    Clipboard.setData(ClipboardData(text: '${q.text}\n— ${q.source}'));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم نسخ القول')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final today = quoteOfDay(DateTime.now());
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      children: [
        const PageHeader(
          title: 'الحِكَم',
          subtitle: 'من أقوال الإمام علي بن أبي طالب (ع)',
        ),
        GlassCard(
          padding: const EdgeInsets.all(20),
          highlight: AppColors.gold,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('قول اليوم',
                  style: TextStyle(
                      color: AppColors.gold, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              Text(today.text,
                  style: const TextStyle(fontSize: 20, height: 1.9)),
              const SizedBox(height: 8),
              Text(today.source,
                  style: const TextStyle(color: Colors.white60, fontSize: 12)),
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton.icon(
                  onPressed: () => _copy(context, today),
                  icon: const Icon(Icons.copy_rounded, size: 18),
                  label: const Text('نسخ'),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        for (final q in kAliQuotes)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: GlassCard(
              onTap: () => _copy(context, q),
              child: Text(q.text,
                  style: const TextStyle(fontSize: 16, height: 1.8)),
            ),
          ),
      ],
    );
  }
}

// ============================================================
// الأعمال (مع تسجيل الإنجاز)
// ============================================================
class DeedsPage extends StatefulWidget {
  const DeedsPage({super.key});

  @override
  State<DeedsPage> createState() => _DeedsPageState();
}

class _DeedsPageState extends State<DeedsPage> {
  Settings? _s;
  List<int> _sel = [];

  @override
  void initState() {
    super.initState();
    Settings.load().then((s) {
      if (!mounted) return;
      setState(() {
        _s = s;
        _sel = deedsOf(s, DateTime.now());
      });
    });
  }

  Future<void> _toggle(int i) async {
    final s = _s;
    if (s == null) return;
    setState(() {
      if (_sel.contains(i)) {
        _sel.remove(i);
      } else {
        _sel.add(i);
      }
    });
    await setDeeds(s, DateTime.now(), _sel);
    kSummaryVersion.value++;
  }

  @override
  Widget build(BuildContext context) {
    return DetailScaffold(
      title: 'أعمال تزيد الحسنات',
      child: _s == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
              children: [
                PageHeader(
                  title: 'أعمال اليوم',
                  subtitle:
                      'أنجزت ${_sel.length} من ${kGoodDeeds.length} اليوم',
                ),
                for (var i = 0; i < kGoodDeeds.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: GlassCard(
                      onTap: () => _toggle(i),
                      child: Row(
                        children: [
                          Icon(
                            _sel.contains(i)
                                ? Icons.check_circle_rounded
                                : Icons.radio_button_unchecked,
                            color: AppColors.gold,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(kGoodDeeds[i],
                                style: const TextStyle(
                                    fontSize: 15, height: 1.5)),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
    );
  }
}

// ============================================================
// اللبس
// ============================================================
class OutfitPage extends StatelessWidget {
  const OutfitPage({super.key});

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now().weekday - 1;
    return DetailScaffold(
      title: 'ألوان اللبس',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        children: [
          const PageHeader(
            title: 'ألوان اللبس',
            subtitle: 'اختيار منسجم لكل يوم من أيام الأسبوع',
          ),
          for (var i = 0; i < kOutfits.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: GlassCard(
                highlight: i == today ? AppColors.gold : null,
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${kDayNames[i]}${i == today ? '  ·  اليوم' : ''}',
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                              color: i == today ? AppColors.gold : null,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(kOutfits[i].name,
                              style: const TextStyle(fontSize: 15)),
                          Text(kOutfits[i].description,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 13)),
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        for (final c in kOutfits[i].swatches)
                          Container(
                            width: 26,
                            height: 26,
                            margin: const EdgeInsets.only(left: 6),
                            decoration: BoxDecoration(
                              color: c,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white54),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ============================================================
// الطعام
// ============================================================
class FoodPage extends StatelessWidget {
  const FoodPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DetailScaffold(
      title: 'طعام صحي',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        children: [
          const PageHeader(
            title: 'طعام صحي',
            subtitle: 'اقتراحات متوازنة لفطورك ومشروباتك ووجباتك',
          ),
          for (final section in kFood.entries) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 8, 4, 8),
              child: Text(section.key,
                  style: const TextStyle(
                      color: AppColors.gold,
                      fontWeight: FontWeight.w800,
                      fontSize: 18)),
            ),
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final item in section.value)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 5),
                      child: Text('•  $item',
                          style: const TextStyle(fontSize: 15, height: 1.5)),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
        ],
      ),
    );
  }
}

// ============================================================
// مؤقت التركيز (بومودورو)
// ============================================================
class PomodoroPage extends StatefulWidget {
  const PomodoroPage({super.key});

  @override
  State<PomodoroPage> createState() => _PomodoroPageState();
}

class _PomodoroPageState extends State<PomodoroPage> {
  static const int _focusSec = 25 * 60;
  static const int _breakSec = 5 * 60;

  int _left = _focusSec;
  bool _running = false;
  bool _isFocus = true;
  Timer? _t;

  int get _total => _isFocus ? _focusSec : _breakSec;

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  void _start() {
    if (_running) return;
    setState(() => _running = true);
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_left <= 1) {
        _finish();
      } else {
        setState(() => _left--);
      }
    });
  }

  void _pause() {
    _t?.cancel();
    setState(() => _running = false);
  }

  void _reset() {
    _t?.cancel();
    setState(() {
      _running = false;
      _left = _total;
    });
  }

  void _finish() {
    _t?.cancel();
    final wasFocus = _isFocus;
    NotificationService.showNow(
      title: wasFocus ? 'انتهى وقت التركيز ☕' : 'انتهت الاستراحة 📚',
      body: wasFocus ? 'خذ استراحة قصيرة' : 'ارجع للدراسة بتركيز',
    );
    setState(() {
      _isFocus = !_isFocus;
      _running = false;
      _left = _total;
    });
  }

  @override
  Widget build(BuildContext context) {
    final mm = (_left ~/ 60).toString().padLeft(2, '0');
    final ss = (_left % 60).toString().padLeft(2, '0');
    return DetailScaffold(
      title: 'مؤقت التركيز',
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_isFocus ? 'وقت التركيز' : 'استراحة',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 24),
            SizedBox(
              width: 240,
              height: 240,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(
                    value: _left / _total,
                    strokeWidth: 10,
                    color: AppColors.gold,
                    backgroundColor: Colors.white12,
                  ),
                  Text('$mm:$ss',
                      style: const TextStyle(
                          fontSize: 48, fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            const SizedBox(height: 28),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton.filled(
                  onPressed: _running ? _pause : _start,
                  icon: Icon(_running ? Icons.pause : Icons.play_arrow),
                  iconSize: 36,
                ),
                const SizedBox(width: 16),
                IconButton.outlined(
                  onPressed: _reset,
                  icon: const Icon(Icons.refresh),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
