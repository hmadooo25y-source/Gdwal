import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'content.dart';
import 'notification_service.dart';
import 'prayer_service.dart';
import 'routine.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  runApp(const PlannerApp());
}

class PlannerApp extends StatelessWidget {
  const PlannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مخطط اليوم',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const HomePage(),
    );
  }
}

String fmt(DateTime t) =>
    '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _loading = true;
  String? _error;
  List<PlanItem> _items = [];
  Map<String, bool> _done = {};
  late SharedPreferences _prefs;

  String get _dayKey {
    final n = DateTime.now();
    return '${n.year}-${n.month}-${n.day}';
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      final today = DateTime.now();
      final prayers = await PrayerService.fetch(today);
      _items = buildDay(today, prayers);
      _done = {
        for (final i in _items) i.id: _prefs.getBool('$_dayKey-${i.id}') ?? false,
      };
      await _scheduleWeek();
    } catch (_) {
      _error =
          'تعذّر تحميل أوقات الصلاة. تأكد من اتصال الإنترنت ثم أعد فتح التطبيق.';
    }
    if (mounted) setState(() => _loading = false);
  }

  /// يجدول إشعارات الأيام السبعة القادمة (أوقات الصلاة تتغير يومياً)
  Future<void> _scheduleWeek() async {
    await NotificationService.cancelAll();
    final base = DateTime.now();
    var motivationIndex = 0;

    for (var d = 0; d < 7; d++) {
      final day = DateTime(base.year, base.month, base.day).add(Duration(days: d));
      final prayers = await PrayerService.fetch(day);
      final list = buildDay(day, prayers);

      for (var i = 0; i < list.length; i++) {
        final it = list[i];
        final body = it.isPrayer
            ? 'حيّ على الصلاة… حيّ على الفلاح'
            : kMotivation[motivationIndex++ % kMotivation.length];

        await NotificationService.schedule(
          id: d * 100 + i,
          when: it.time,
          title: '${it.emoji} ${it.title}',
          body: body,
          url: it.song?.url,
        );
      }
    }
  }

  void _toggle(String id, bool value) {
    setState(() => _done[id] = value);
    _prefs.setBool('$_dayKey-$id', value);
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('مخطط اليوم'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'اليوم'),
              Tab(text: 'الأعمال'),
              Tab(text: 'اللبس'),
              Tab(text: 'الطعام'),
            ],
          ),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(_error!, textAlign: TextAlign.center),
                    ),
                  )
                : TabBarView(
                    children: [
                      _dayTab(),
                      _simpleList(kGoodDeeds, Icons.favorite_outline),
                      _outfitTab(),
                      _simpleList(kHealthyFood, Icons.restaurant_outlined),
                    ],
                  ),
      ),
    );
  }

  Widget _dayTab() {
    final done = _done.values.where((v) => v).length;
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text('أنجزت $done من ${_items.length} مهمة اليوم'),
        ),
        for (final it in _items)
          CheckboxListTile(
            value: _done[it.id] ?? false,
            onChanged: (v) => _toggle(it.id, v ?? false),
            title: Text('${it.emoji} ${it.title}'),
            subtitle: Text(fmt(it.time)),
            secondary: it.song == null
                ? null
                : IconButton(
                    tooltip: it.song!.title,
                    icon: const Icon(Icons.music_note),
                    onPressed: () => launchUrl(
                      Uri.parse(it.song!.url),
                      mode: LaunchMode.externalApplication,
                    ),
                  ),
          ),
      ],
    );
  }

  Widget _simpleList(List<String> data, IconData icon) {
    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 8),
      children: [
        for (final s in data) ListTile(leading: Icon(icon), title: Text(s)),
      ],
    );
  }

  Widget _outfitTab() {
    final todayIndex = DateTime.now().weekday - 1; // الاثنين = 0
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        for (var i = 0; i < 7; i++)
          Card(
            color: i == todayIndex
                ? Theme.of(context).colorScheme.primaryContainer
                : null,
            child: ListTile(
              leading: const Icon(Icons.checkroom_outlined),
              title: Text(
                kDayNames[i] + (i == todayIndex ? ' (اليوم)' : ''),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(kOutfits[i]),
            ),
          ),
      ],
    );
  }
}
