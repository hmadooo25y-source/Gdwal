import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'config.dart';

/// يُزاد عند تغيير أي إعداد، فتعيد الشاشات تحميل بياناتها وتُعاد الجدولة
final ValueNotifier<int> kDataVersion = ValueNotifier<int>(0);
void notifyDataChanged() => kDataVersion.value++;

String fmtTod(TimeOfDay t) =>
    '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

class CustomTask {
  final String id;
  final String title;
  final String emoji;
  final int hour;
  final int minute;

  const CustomTask({
    required this.id,
    required this.title,
    required this.emoji,
    required this.hour,
    required this.minute,
  });

  Map<String, dynamic> toJson() =>
      {'id': id, 'title': title, 'emoji': emoji, 'h': hour, 'm': minute};

  factory CustomTask.fromJson(Map<String, dynamic> j) => CustomTask(
        id: j['id'] as String,
        title: j['title'] as String,
        emoji: j['emoji'] as String,
        hour: j['h'] as int,
        minute: j['m'] as int,
      );
}

class Settings {
  final SharedPreferences p;
  Settings(this.p);

  static Future<Settings> load() async =>
      Settings(await SharedPreferences.getInstance());

  // ---------- الموقع ----------
  String get cityName => p.getString('city') ?? kCities.first.name;
  double get lat => p.getDouble('lat') ?? kCities.first.lat;
  double get lng => p.getDouble('lng') ?? kCities.first.lng;

  Future<void> setLocation(String name, double lat, double lng) async {
    await p.setString('city', name);
    await p.setDouble('lat', lat);
    await p.setDouble('lng', lng);
  }

  // ---------- الأوقات ----------
  TimeOfDay time(String key, String def) {
    final parts = (p.getString(key) ?? def).split(':');
    return TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
  }

  Future<void> setTime(String key, TimeOfDay t) =>
      p.setString(key, fmtTod(t));

  TimeOfDay get gymTime => time('gymTime', '06:00');
  TimeOfDay get marketTime => time('marketTime', '09:30');
  TimeOfDay get showerTime => time('showerTime', '09:00');
  TimeOfDay get quranTime => time('quranTime', '21:30');

  // ---------- الجيم ----------
  List<int> get gymDays =>
      (p.getStringList('gymDays') ?? ['7', '2', '4']).map(int.parse).toList();

  Future<void> setGymDays(List<int> days) =>
      p.setStringList('gymDays', [for (final d in days) '$d']);

  // ---------- المفاتيح ----------
  bool flag(String key, bool def) => p.getBool(key) ?? def;
  Future<void> setFlag(String key, bool v) => p.setBool(key, v);

  bool get ramadan => flag('ramadan', false);
  bool get adhan => flag('adhan', true);
  bool get adhkar => flag('adhkar', true);
  bool get quranReminder => flag('quranOn', true);

  int get preMinutes => p.getInt('pre') ?? 10;
  Future<void> setPreMinutes(int v) => p.setInt('pre', v);

  int get palette => p.getInt('palette') ?? 0;
  Future<void> setPalette(int v) => p.setInt('palette', v);

  double get volume => p.getDouble('volume') ?? 1.0;
  Future<void> setVolume(double v) => p.setDouble('volume', v);

  // ---------- المهام الشخصية ----------
  List<CustomTask> get customTasks {
    final raw = p.getString('tasks');
    if (raw == null) return [];
    return (jsonDecode(raw) as List)
        .map((e) => CustomTask.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> saveCustomTasks(List<CustomTask> tasks) => p.setString(
      'tasks', jsonEncode([for (final t in tasks) t.toJson()]));

  // ---------- المكتبة الصوتية ----------
  List<String> get audioLibrary => p.getStringList('library') ?? [];
  Future<void> setAudioLibrary(List<String> v) => p.setStringList('library', v);

  String? audioFor(String slot) => p.getString('audio_$slot');

  Future<void> setAudioFor(String slot, String? path) async {
    if (path == null) {
      await p.remove('audio_$slot');
    } else {
      await p.setString('audio_$slot', path);
    }
  }
}
