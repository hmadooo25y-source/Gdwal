import 'package:flutter/material.dart';

class AppColors {
  static const emerald = Color(0xFF0E6E5C);
  static const gold = Color(0xFFD4AF37);
  static const rose = Color(0xFFE07A5F);
  static const sky = Color(0xFF5BC0EB);
  static const green = Color(0xFF7CB342);
  static const amber = Color(0xFFFFB74D);
  static const indigo = Color(0xFF9575CD);
}

/// لوحة ألوان للخلفية: فجر، نهار، مغرب، ليل
class Palette {
  final String name;
  final List<Color> dawn;
  final List<Color> day;
  final List<Color> sunset;
  final List<Color> night;
  const Palette(this.name, this.dawn, this.day, this.sunset, this.night);
}

const List<Palette> kPalettes = [
  Palette(
    'زمردي وذهبي',
    [Color(0xFF1E2A52), Color(0xFF8E6C8A)],
    [Color(0xFF0E6E5C), Color(0xFF1F8A7A)],
    [Color(0xFF7A3E2B), Color(0xFF2D1B3D)],
    [Color(0xFF070F1F), Color(0xFF13294B)],
  ),
  Palette(
    'ليلي ملكي',
    [Color(0xFF2B2D6E), Color(0xFF7A5C9E)],
    [Color(0xFF1E3A8A), Color(0xFF3B82C4)],
    [Color(0xFF4A2C6E), Color(0xFF1B1140)],
    [Color(0xFF05071A), Color(0xFF141E45)],
  ),
  Palette(
    'وردي دافئ',
    [Color(0xFF5C2A4A), Color(0xFFE09A7A)],
    [Color(0xFFB5544A), Color(0xFFE8957A)],
    [Color(0xFF7A2E3D), Color(0xFF2D1020)],
    [Color(0xFF1A0A14), Color(0xFF3A1A2E)],
  ),
  Palette(
    'رملي هادئ',
    [Color(0xFF4A4030), Color(0xFFC9A46B)],
    [Color(0xFF7C6A46), Color(0xFFC9B18A)],
    [Color(0xFF5A3B22), Color(0xFF2B1D12)],
    [Color(0xFF141008), Color(0xFF33291A)],
  ),
];

/// فهرس اللوحة الحالية، يُحدَّث عند تغيير المظهر
final ValueNotifier<int> kPaletteIndex = ValueNotifier<int>(0);

List<Color> timeGradient(DateTime t) {
  final p = kPalettes[kPaletteIndex.value];
  final h = t.hour;
  if (h >= 4 && h < 6) return p.dawn;
  if (h >= 6 && h < 16) return p.day;
  if (h >= 16 && h < 19) return p.sunset;
  return p.night;
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.emerald,
    brightness: Brightness.dark,
  ).copyWith(primary: AppColors.gold, secondary: AppColors.emerald);

  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: Colors.transparent,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
    ),
  );
}
