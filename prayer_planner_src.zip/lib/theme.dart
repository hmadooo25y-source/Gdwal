import 'package:flutter/material.dart';

class AppColors {
  static const emerald = Color(0xFF0E6E5C);
  static const gold = Color(0xFFD4AF37);
  static const rose = Color(0xFFE07A5F);
  static const sky = Color(0xFF5BC0EB);
  static const green = Color(0xFF7CB342);
  static const amber = Color(0xFFFFB74D);
  static const indigo = Color(0xFF9575CD);
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.emerald,
    brightness: Brightness.dark,
  ).copyWith(primary: AppColors.gold, secondary: AppColors.emerald);

  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: Colors.transparent,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
    ),
  );
}

/// خلفية متدرجة تتغير حسب وقت اليوم: فجر، نهار، مغرب، ليل
List<Color> timeGradient(DateTime t) {
  final h = t.hour;
  if (h >= 4 && h < 6) {
    return const [Color(0xFF1E2A52), Color(0xFF8E6C8A)]; // فجر
  }
  if (h >= 6 && h < 16) {
    return const [Color(0xFF0E6E5C), Color(0xFF1F8A7A)]; // نهار
  }
  if (h >= 16 && h < 19) {
    return const [Color(0xFF7A3E2B), Color(0xFF2D1B3D)]; // مغرب
  }
  return const [Color(0xFF070F1F), Color(0xFF13294B)]; // ليل
}
